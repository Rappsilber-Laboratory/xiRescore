--
-- Data for Name: peaklist; Type: TABLE DATA; Schema: public; Owner: test
--

COPY public.peaklist (id, search_id, name, path) FROM stdin;
3862f3f6-c550-4ce0-88cf-8aaa6b7dd030	fdbe9e59-2baa-44cb-b8cb-e8b7a590e136	recal_B230608_07_Lumos_ZC_QC_140_xChEP_DSSO_pepSECf6-1.mgf	
d85e939b-e6a7-450b-a6ec-ea02d1f9907e	fdbe9e59-2baa-44cb-b8cb-e8b7a590e136	recal_B230608_08_Lumos_ZC_QC_140_xChEP_DSSO_pepSECf6-2.mgf	
eb62a7d7-62f0-4e8f-b8b1-1b703ab52f37	fdbe9e59-2baa-44cb-b8cb-e8b7a590e136	recal_B230608_09_Lumos_ZC_QC_140_xChEP_DSSO_pepSECf7-1.mgf	
74d89689-5783-479a-b19d-2047538f32fa	fdbe9e59-2baa-44cb-b8cb-e8b7a590e136	recal_B230608_10_Lumos_ZC_QC_140_xChEP_DSSO_pepSECf7-2.mgf	
8c4d6aba-7d49-4cd6-b892-bbc55a4ecb0f	fdbe9e59-2baa-44cb-b8cb-e8b7a590e136	recal_B230608_11_Lumos_ZC_QC_140_xChEP_DSSO_pepSECf8-1.mgf	
eaad03d7-760e-4731-8711-64e5794d6dfd	fdbe9e59-2baa-44cb-b8cb-e8b7a590e136	recal_B230608_12_Lumos_ZC_QC_140_xChEP_DSSO_pepSECf8-2.mgf	
5174f9f1-45dd-44c3-9bf5-c3cdb89731e6	fdbe9e59-2baa-44cb-b8cb-e8b7a590e136	recal_B230608_14_Lumos_ZC_QC_140_xChEP_DSSO_pepSECf9-1.mgf	
d6c5f563-96ac-493d-b773-12882ba8a5f3	fdbe9e59-2baa-44cb-b8cb-e8b7a590e136	recal_B230608_15_Lumos_ZC_QC_140_xChEP_DSSO_pepSECf9-2.mgf	
6d7e09b4-e43f-4634-ab0e-7a89647f2ad0	fdbe9e59-2baa-44cb-b8cb-e8b7a590e136	recal_B230608_17_Lumos_ZC_QC_140_xChEP_DSSO_pepSECf10-1.mgf	
f9bfd283-a830-4d3b-9653-dc4a06e34f19	fdbe9e59-2baa-44cb-b8cb-e8b7a590e136	recal_B230608_18_Lumos_ZC_QC_140_xChEP_DSSO_pepSECf10-2.mgf	
ed717e9e-7bca-4f18-b0d6-ac9cf974e783	fdbe9e59-2baa-44cb-b8cb-e8b7a590e136	recal_B230608_19_Lumos_ZC_QC_140_xChEP_DSSO_pepSECf5-1.mgf	
b523ee77-baa8-4fa5-8350-034dd8681466	fdbe9e59-2baa-44cb-b8cb-e8b7a590e136	recal_B230608_20_Lumos_ZC_QC_140_xChEP_DSSO_pepSECf5-2.mgf	
\.
